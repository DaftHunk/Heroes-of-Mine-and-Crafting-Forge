―――――――――――――――――――――――――――――――――――――――――
This data pack has been made by PauseKawa
―――――――――――――――――――――――――――――――――――――――――

Only websites I will use to upload my content will always be Planet Minecraft (planetminecraft.com) and my own host (pausekawa.net).
If this data pack has been downloaded from another website, that means my content has been stolen, so be careful with its content: this data pack can then be outdated, or potentially even contains malicious files. Please be sure to download it from one of the websites/plateforms mentioned in the "Links & Contact" section below and nowhere else.

―――――――――――――――――――――――――――――――――――――――――
LICENCE
―――――――――――――――――――――――――――――――――――――――――

This data packs follow the CC BY-NC-SA 3.0 licence: https://creativecommons.org/licenses/by-nc-sa/3.0/legalcode

You're free to share and adapt this content under the following terms:
    • Attribution (BY) — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
    • NonCommercial (NC) — You may not use the material for commercial purposes.
    • ShareAlike (SA) — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

―――――――――――――――――――――――――――――――――――――――――
LINKS & CONTACT
―――――――――――――――――――――――――――――――――――――――――

Email: contact@pausekawa.net
Discord: https://discord.gg/usXV6duaeZ
Website: https://www.pausekawa.net
Planet Minecraft page: https://www.planetminecraft.com/member/pausekawa/
Youtube channel: https://www.youtube.com/@PauseKawa