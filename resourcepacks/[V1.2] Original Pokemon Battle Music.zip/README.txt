Installation:
Make sure to delete any previous version before installing!
Drag and drop the "[V1.2] Original Pokemon Battle Music" Folder into your "resourcepacks" Folder

Known Issues:
- Sometimes music won't play, I'm unsure what causes this but it plays for the most part

- If you use the "Sound Physics" Mod, you won't hear any battle music, here is how to fix that (Found/Brought To My Attention by @3evee, @ellie69420, and @breezyasha)
Go to your "config" Folder (where "mods" and "resourcepack" folder are) then "sound_physics" Folder and open the "allowed_sounds.properties" file then look for the following and change them from true to false
cobblemon\:battle.pvw.default
cobblemon\:battle.pvp.default