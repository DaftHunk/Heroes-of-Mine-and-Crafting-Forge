Drodi's Illagers v5.1

Support & Bug Reports
--------------------
Found a bug or need help with something?
Join my Discord server (https://discord.gg/uKFmfG3s2B) and head over to the bug reporting channel.

Before reporting:
- Make sure you have the necessary mods (usually EMF & ETF) and that they are up to date.
- Check if the bug is actually caused by this resource pack. You can do this by removing all other packs except this one to see if the issue persists.

Credits
-------
- Keniu & Rustillery → Inspiration from their packs "Illagers Reborn" and "Rustillery’s Classy Illagers"
- Shrimpsnail → Help with the Witch design + made the Witch’s cauldron
- Blockixel Artistry → Heavy inspiration for the Iceologer design
- Reijvi → General inspiration for the pack’s style

License
-------
Drodi's Illagers pack (c) by Drodi
Licensed under an All Rights Reserved License
